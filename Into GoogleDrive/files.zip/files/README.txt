Please download other required files such as raw data and pickle dump files from the following google drive : 

https://drive.google.com/drive/folders/0B6mBWYUorymvVGMybXQtZFlCZkU?usp=sharing